function [data,labels] = banana_data(N,Param)
if nargin == 0
    N = 1000;
end
if nargin < 2
    Param.noise = 0.1;
end

noise = Param.noise;
if numel(N) == 1
    Ntot = N;
    N_cl = ceil(N/2);
    N = ones(1,2) * N_cl; % cluster sizes
else % otherwise the cluster numbers are already provided
    Ntot = sum(N);
end 
data = []; labels = [];
theta = rand(N(1),1)*pi;
data = [data;sin(theta) cos(theta)];
theta = rand(N(1),1)*pi;
data = [data;sin(theta)+1 cos(theta)];
data = data + randn(size(data))*noise;
labels = [ones(N_cl,1);ones(N_cl,1)*2];

data = data(1:Ntot,:);
labels = labels(1:Ntot);

% % Visual Check
% close all
% figure, hold on
% scatter(data(:,1),data(:,2),12,labels)
% axis equal
% title(size(data,1))