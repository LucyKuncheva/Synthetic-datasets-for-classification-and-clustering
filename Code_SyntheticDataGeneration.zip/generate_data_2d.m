function [data, labels] = generate_data_2d(name, N)
%=======================================================================
%GENERATE_DATA_2D Generates a chosen dataset
%    [data, labels] = generate_data_2d(name, N)
%    Returns data and labels for a chosen dataset. The collection of
%    datasets has been created to replicate popular toy datasets in the
%    literature on clustering.
%
%   Input -----
%      'name': the chosen dataset (string, default = 'spirals')
%      'N': number of points (default = 300) Where there is uniform
%           background noise in the data, 10% of the points are allocated
%           to the noise.
%
%   Output -----
%      'data':
%      'labels':
%
%   Datasets available to generate:
%
%   aggregation = multiple clusters, from [19] FIXED
%
%   aligned_bananas = two aligned banana-shaped clusters [8] 
%
%   arcs = four parallel "arcs" with 26 points on each [3]
%
%   balls_and_baguettes = 3 balls and 2 baguettes, all Gaussians [12]
%
%   bars = two adjacent rectangles, each with increasing density from left
%             to right [2]
%
%   boat = small dataset looking like a boat from above (boat contour 
%             and two seats) [20] FIXED
%
%   cigar = four clusters, two oblong and two compact gaussians [2]
%
%   circle_and_3_gaussians = a circle and three small gaussian clusters
%             inside [1]
%
%   concentric_circles_2 = two concentric circles "rings" in [15][8]
%
%   concentric_circles_3 = concentric circles - in some form used in 
%             [1][2][6][7][8][11]
%
%   enclosure = a grid with a box with a rectangle and a diamond in it [12]
%
%   flower = 5 gaussian clusters positioned as the petals of a flower and a
%            centre [12]
%
%   filled_circle = a circle filled with a gaussian [14][20]
%   
%   filled_circle_2 = two filled circles [14]
%
%   four_corners_clear = four compact clusters in four corners of a 
%             square, no noise [3]
%
%   four_corners_noise = four compact clusters in four corners of a 
%             square, uniform noise [3]
%
%   four_lines = four noisy parallel line segments of different length [1]
%             2 "noisy lines" in [20]
%
%   gaussians_3_touching = three gaussians on a diagonal, touching,
%             "overlapping" in [4]
%
%   gaussians_5_compact = 5 distinct gaussian clusters with uniform
%             noise in the background [1][5]
%
%   gaussians_5_unequal = 5 distinct gaussian clusters; 2 small and
%            3 bigger; uniform noise in the background [1][5]
%
%   gaussians_1_big_2_small = three distinct gaussian clusters [1][5]
%
%   gestalt = a "classic" dataset from teh 1970s [19] FIXED
%
%   half_rings = also "arcs", "two moons"[9] two banana-shaped clusters 
%             [1][4], "bananas" [15] [20]
%
%   happy_wave = a semicircle and a ball above [8]
%
%   orange = two halfs of a sphere (uniform distribution) seprated by a 
%             stripe on the diameter [4]
%
%   petals = a small datasets, contours of 4 petals [20] FIXED
%
%   random1 = four clusters in random configuration: a square a
%            compact gaussian cluster, a rotated Y-shaped cluster and a
%            small elliptical cluster [1] [2]
%
%   random2 = four square clusters enclosed in a space defined by two
%            right-angle clusters [1]
%
%   random3 = everything and the kitchen sink :) two spirals, three
%             concentric circles an eliptical cluster and a gaussian
%             cluster [1]
%
%   randomised_normal = a collection of gaussian clusters with centres in
%             [0,20]x[0,20] with random covariance matrices. The number of
%             clusters is randomly chosen between 2 and 20. Similar to [18]
%             4 gaussians in [20]
%
%   randomised_triangle = a collection of clusters with triangular
%             distribution with random position 
%             of the peaks in [0,20]x[0,20]. The lower and higher 
%             values are within 5 off the peak. The number of
%             clusters is randomly chosen between 2 and 20. 
%             Similar to [18]
%
%   saturn = a small dataset of a circle and an ellipse [20] FIXED
%
%   sixteen_blocks = a regular grid of blocks with 4-by-4 points in each
%             block [20]
%
%   spirals = k intertwined spirals [1][4][8][12][20] "pinwheel"[14]
%             Params.noise = 0.02; - scatter about the spiral
%             Params.n_clust = 2; - number of spirals
%             Params.revolutions = 1; - revolutions of each spiral
%
%   stormclouds = two oblong horizontal rectangular clusters [14]
%
%   t_and_u = letters T and U sideways [3]
%
%   ten_spherical = ten gaussian clusters of equal variance AD_10_2 [13]
%             Sph_10_2 [12] Data_10_2 [4]
%
%   three_by_three = 9 gauissian, well-separated, clusters on a grid [3]
%
%   three_circles = three intersecting circles [10]
%
%   two_diamonds = two touching diamonds, uniform distribution [4]
%
%   two_u = an upright and an inverted u-shapes [12]
%
%   wingnut = two vertical rectangles with high dnsities in the top right
%             and bottom left corners, respectively [4]
%
%   worms = a random figure with 4 worm-like clusters [1][2]
%
%   xor = four gaussin clusters in 4 corners [14] "spheres", 50 points
%             per class in [3]
%
%   xor_big_and_small = the same as xor but two opposite clusters are
%             smaller in diameter [3]
%
%   xor_different_cardinalities = the same as xor but two opposite 
%             clusters have 1/4 of the points of the bigger clusters [3]
%   
%   yin_yang = A circle split into Yin-Yang parts. Two class labels.
%             Regular grid points (fixed number of a given grid size) [10]
%
% [1] Cheng19
% [2] Duarte13
% [3] Gurrutxaga11
% [4] JoseGarcia21
% [5] Liu10 impact of density + noise on CVI
% [6] Tuzel09
% [7] Kulis09
% [8] Khashabi00
% [9] Wang05
% [10] He14
% [11] Levine01
% [12] Saha12
% [13] Maulik02 
% [14] Klein02
% [15] Abin20
% [16] Abin20density
% [17] Arbelaitz13 compact 4 gaussians in different configurations
% [18] Iglesias20
% [19] Safraz19
% [20] KunchevaVetrov06
% 
%========================================================================

% (c) Lucy Kuncheva                                                 ^--^
% 02.05.2023 -----------------------------------------------------  \oo/
% -------------------------------------------------------------------\/-%

if nargin < 2
    N = 200;
end
if nargin == 0 % default example
    name = 'spirals';
end

o = @(a,b) ones(a,1)*b; % label generator

switch name
    
    case 'aggregation'
        p = load('DataFromLiterature/Aggregartion_Safraz19.txt');
        data = p(:,[1,2]); labels = p(:,end);
        
    case 'aligned_bananas'
        [data,labels] = banana_data(N);

    case 'arcs'
        theta = linspace(pi/2-pi/3,pi/2+pi/3,26);
        data = [theta(:) sin(theta(:));...
            theta(:) sin(theta(:))+.3;...
            theta(:) sin(theta(:))+.6;...
            theta(:) sin(theta(:))+.9];
        labels = [o(26,1);o(26,2);o(26,3);o(26,4)];

    case 'balls_and_baguettes'
        Param.mu = [-5,8;-6,2;2,13;4,4;5,0];
        Param.sigma = {3,[6,-2;-2,0.8],1,[6,2;2,0.8],0.7};
         [data,labels] = gaussian_data(N,Param);

    case 'bars'
        N_cl = ceil(N/2);
        s = 0.4;
        % Ensure there are enough points to sample from
        t = randn(3*N_cl,1)*s + 1;
        while sum(t > 0 & t < 1) < N_cl
            t = randn(3*N_cl,1)*s + 1;
        end
        temp = t(t > 0 & t < 1); % within the interval [0,1]
        data = [temp(randperm(numel(temp),N_cl)) rand(N_cl,1)];
        t = randn(3*N_cl,1)*s + 1;
        while sum(t > 0 & t < 1) < N_cl
            t = randn(3*N_cl,1)*s + 1;
        end
        temp = t(t > 0 & t < 1); % within the interval [0,1]
        data = [data;temp(randperm(numel(temp),N_cl))+1, rand(N_cl,1)];
        labels = [o(N_cl,1);o(N_cl,2)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'boat'
        N_cl = ceil(N/3);
        s = 0.1; % noise
        % ellipse
        theta = rand(N_cl,1)*2*pi;
        a = 2; b = 1;
        data = [sin(theta)*a,cos(theta)*b];
        data = data + randn(size(data))*s;
        data = [data; randn(N_cl,1)*0.1-0.7, randn(N_cl,1)*0.1;...
            randn(N_cl,1)*0.1+0.7, randn(N_cl,1)*0.1];
        labels = [o(N_cl,1);o(N_cl,2);o(N_cl,3)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);


    case 'cigar'
        N_cl = ceil(N/4);
        s = 1;
        s1 = 0.5;
        s2 = 0.1;
        data = [rand(N_cl,1)*s1-s1/2, randn(N_cl,1)*s];
        data = [data; rand(N_cl,1)*s1-s1/2+2, randn(N_cl,1)*s];
        data = [data; randn(N_cl,1)*s2, randn(N_cl,1)*s2-4];
        data = [data; randn(N_cl,1)*s2+2, randn(N_cl,1)*s2-4];
        labels = [o(N_cl,1);o(N_cl,2);o(N_cl,3);o(N_cl,4)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);


    case 'circle_and_3_gaussians' %----------------------------------------
        N_cl = ceil(N/4);
        noise = 0.2;
        s = 0.02; % sigma
        r = 2; % radius
        data = [];
        theta = rand(N_cl,1)*2*pi;
        data =  [data;sin(theta).*r, cos(theta).*r];
        data = data + randn(size(data))*noise; % noise on the circle
        labels = o(N_cl,1);
        mu = [-0.6,0.4;0, -0.5;0.6,0.4]; % cluster centroids
        for i = 1:3
            data = [data; mvnrnd(mu(i,:),ones(1,size(mu,2))*s,N_cl)];
            labels = [labels; o(N_cl,i+1)];
        end
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'circle_2_rectangles'
        [data,labels] = circle_2_rectangles(N);

     case 'concentric_circles_2' %------------------------------------------
        N_cl = ceil(N/2);
        noise = 0.1; 
        r = [0.3,1]; % radii
        data = [];
        theta = rand(N_cl,1)*2*pi;
        data =  [data;sin(theta).*r(1), cos(theta).*r(1)];
        theta = rand(N_cl,1)*2*pi;
        data =  [data;sin(theta).*r(2), cos(theta).*r(2)];
        labels = [o(N_cl,1);o(N_cl,2)];
        data = data + randn(size(data))*noise;
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'concentric_circles_3' %------------------------------------------
        N_cl = ceil(N/3);
        noise = 0.1; 
        r = [0.3,1.2,2]; % radii
        data = [];
        theta = rand(N_cl,1)*2*pi;
        data =  [data;sin(theta).*r(1), cos(theta).*r(1)];
        theta = rand(N_cl,1)*2*pi;
        data =  [data;sin(theta).*r(2), cos(theta).*r(2)];
        theta = rand(N_cl,1)*2*pi;
        data =  [data;sin(theta).*r(3), cos(theta).*r(3)];
        labels = [o(N_cl,1);o(N_cl,2);o(N_cl,3)];
        data = data + randn(size(data))*noise;
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'enclosure'
        [data,labels] = enclosure; % no number can be set; all fixed

    case 'flower'
        Param.mu = [10,10;6,10;10,6;10,14;14,10];
        Param.sigma = {1,1,1,1,1};
        [data,labels] = gaussian_data(N,Param);

    case 'filled_circle'
        N_cl = ceil(N/2);
        mu = [0,0];
        r_out = 4; % radius
        noise = 0.1;
        s = 1; % sigma for the inner cluster
        theta = randn(N_cl,1)*2*pi;
        data = [sin(theta)*r_out, cos(theta)*r_out];
        data = data + randn(size(data))*noise;
        data = [data; mvnrnd(mu,eye(size(mu,2))*s,N_cl)];
        labels = [o(N_cl,1); o(N_cl,2)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'filled_circle_2'
        N_cl = ceil(N/2);
        [data1,labels1] = generate_data_2d('filled_circle',N_cl);
        [data2,labels2] = generate_data_2d('filled_circle',N_cl);
        data = [data1;data2 + 7];
        labels = [labels1;labels2 + 2];
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'four_corners_clear'
        sz = 4; % space_size
        N_cl = ceil(N/4); % points in each cluster
        data = [rand(N_cl,2); rand(N_cl,2) + sz;rand(N_cl,1),...
            rand(N_cl,1)+sz;rand(N_cl,1)+sz, rand(N_cl,1)];
        labels = [o(N_cl,1);o(N_cl,2);o(N_cl,3);o(N_cl,4)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'four_corners_noise'
        sz = 4;
        N_noise = ceil(0.1*N); % noise points in the background
        [data,labels] = generate_data_2d('four_corners_clear',N-N_noise);
        data_noise = rand(N_noise,2) * sz;
        % label the noise
        di = pdist2(data_noise,[0,0;sz,sz;0,sz;sz,0]+0.5);
        [~,labels_noise] = min(di,[],2);
        data = [data;data_noise];
        labels = [labels;labels_noise(:)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);


    case 'four_lines'
        noise = 0.02;
        N_cl = ceil(N/4);
        no = @() noise*randn(N_cl,1);
        offset = 0.25;
        x1 = rand(N_cl,1)*0.4+0.5; x2 = rand(N_cl,1)*1.2+0.1;
        x3 = rand(N_cl,1)*0.3+0.4; x4 = rand(N_cl,1)*1+0.2;
        data = [x1,0.1*x1+offset+no();x2,0.1*x2+2*offset+no();...
            x3,0.1*x3+3*offset+no();x4,0.1*x4+4*offset+no()];
        labels = [o(N_cl,1);o(N_cl,2);o(N_cl,3);o(N_cl,4)];

    case 'gaussians_3_touching'
        Param.mu = [0,0;5,5;10,10];
        Param.sigma = {1,1,1};
        [data,labels] = gaussian_data(N,Param);

    case 'gaussians_5_compact' %-------------------------------------------
        mu = [-3,4;-3,-2;0,1;2,5;4,-2]; % cluster centroids
        K = size(mu,1); % number of Gaussian clusters
        s = 0.07; % sigma - the same for all clusters
        N_noise = ceil(0.1*N); % noise points in the background
        N_cl = ceil((N-N_noise)/K); % points in each cluster
        data = []; labels = [];
        for i = 1:K
            data = [data; mvnrnd(mu(i,:),ones(1,size(mu,2))*s,N_cl)];
            labels = [labels; o(N_cl,i)];
        end
        mi = min(data); ma = max(data);
        data_noise = rand(N_noise,2);
        data_noise = repmat(mi,N_noise,1) - 2 + ...
            data_noise .* (repmat(ma - mi,N_noise,1)+2);
        % label the noise
        di = pdist2(data_noise,mu);
        [~,labels_noise] = min(di,[],2);

        data = [data;data_noise];
        labels = [labels;labels_noise];
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'gaussians_5_unequal' %-------------------------------------------
        mu = [-5,-1;-3,-4;2,8;8,9;9,-2]; % cluster centroids
        K = size(mu,1); % number of Gaussian clusters
        N_noise = ceil(0.1*N); % noise points in the background
        N_cl = ceil((N-N_noise)/K); % points in each cluster
        data = []; labels = [];
        s = [0.1,0.1,0.8,0.8,0.8];
        for i = 1:K
            data = [data; mvnrnd(mu(i,:),ones(1,size(mu,2))*s(i),N_cl)];
            labels = [labels; o(N_cl,i)];
        end
        mi = min(data); ma = max(data);
        data_noise = rand(N_noise,2);
        data_noise = repmat(mi,N_noise,1) - 2 + ...
            data_noise .* (repmat(ma - mi,N_noise,1)+2);
        % label the noise
        di = pdist2(data_noise,mu);
        [~,labels_noise] = min(di,[],2);

        data = [data;data_noise];
        labels = [labels;labels_noise];
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'gaussians_1_big_2_small' %-----------------------------------
        mu = [0,0;-3,-5;3,-5]; % cluster centroids
        K = size(mu,1); % number of Gaussian clusters
        s1 = 0.9; % sigma for the big class
        s2 = 0.2; % sigma for the smaller clusters
        N_cl = ceil(N/K); % points in each cluster
        data = []; labels = [];
        data = [data; mvnrnd(mu(1,:),ones(1,size(mu,2))*s1,N_cl)];
        labels = [labels; o(N_cl,1)];
        data = [data; mvnrnd(mu(2,:),ones(1,size(mu,2))*s2,N_cl)];
        data = [data; mvnrnd(mu(3,:),ones(1,size(mu,2))*s2,N_cl)];
        labels = [labels; o(N_cl,2); o(N_cl,3)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'gestalt'
        p = load('DataFromLiterature/GestaltClusters_Safraz19.txt');
        data = p(:,[1,2]); labels = p(:,end);

    case 'happy_wave'
         N_cl = ceil(N/2); % points in each cluster
         noise = 0.1;
         theta = -pi/2-rand(N_cl,1)*pi;
         data = [sin(theta) cos(theta)];
         data = data + randn(size(data))*noise;
         data = [data; mvnrnd([0,0],eye(2)*0.02,N_cl)];
         labels = [o(N_cl,1); o(N_cl,2)];
         data = data(1:N,:); % trim off
         labels = labels(1:N);

    case 'orange'
        data = []; labels = [];
        gap = 0.03;
        while size(data,1) < N
            x = rand; y = rand;
            if (x-0.5)^2 + (y-0.5)^2 < .25 && abs(x-0.5) > gap
                data = [data;x,y];
                labels = [labels; (x < 0.5) + 1];
            end
        end

    case 'petals'
        N_cl = ceil(N/4);
        s = 0.05; % noise        
        offset = 3;
        % ellipse
        theta = rand(N_cl,1)*2*pi;
        el = @(a,b,N) [sin(theta)*a,cos(theta)*b];  
        a = 2.3; b = 0.8;
        t = el(a,b,N_cl);
        data = [t(:,1) + offset,t(:,2)];
        t = el(a,b,N_cl);        
        data = [data;t(:,1) - offset,t(:,2)];
        t = el(b,a,N_cl);        
        data = [data;t(:,1),t(:,2)+offset];
        t = el(b,a,N_cl);        
        data = [data;t(:,1),t(:,2)-offset];
        data = data + randn(size(data))*s;
        labels = [o(N_cl,1);o(N_cl,2);o(N_cl,3);o(N_cl,4)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'random1' %-------------------------------------------------------
        N_noise = ceil(0.1*N); % noise points in the background
        N_cl = ceil((N-N_noise)/6); % points in each cluster/subcluster
        mu = [-2,3.3;4,4;-1.5,-2.5;2.5,-1.5;2.5,-3.5;7,-2.5];
        s1 = 0.12;
        data = mvnrnd(mu(1,:),[s1,s1],N_cl); % small gaussian
        data = [data;rand(N_cl,1)*2+mu(2,1)-1, rand(N_cl,1)*2+mu(2,2)-1];
        labels = [o(N_cl,1);o(N_cl,2)];

        data = [data;mvnrnd(mu(3,:),[3,0;0,0.03],N_cl)]; % Y1
        data = [data;mvnrnd(mu(4,:),[0.5,0.2;0.2,0.1],N_cl)]; % Y1
        data = [data;mvnrnd(mu(5,:),[0.5,-0.2;-0.2,0.1],N_cl)]; % Y1
        labels = [labels;o(N_cl*3,3)];
        data = [data;mvnrnd(mu(6,:),[0.6,0;0,0.02],N_cl)]; % Y1
        labels = [labels;o(N_cl,4)];

        mi = min(data); ma = max(data);
        data_noise = rand(N_noise,2);
        data_noise = repmat(mi,N_noise,1) - 2 + ...
            data_noise .* (repmat(ma - mi,N_noise,1)+2);
        % label the noise
        di = pdist2(data_noise,mu);
        [~,labels_noise] = min(di,[],2);
        u = [1,2,3,3,3,4];
        labels_noise = u(labels_noise);

        data = [data;data_noise];
        labels = [labels;labels_noise(:)];

        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'random2' %-------------------------------------------------------
        N_cl = ceil(N/6); % points in each cluster
        noise = 0.2;
        ra = @() rand(N_cl,1);
        data = [ra(), ra(); ra()+2, ra(); ra(), ra()+2; ra()+2, ra()+2];
        labels = [o(N_cl,1);o(N_cl,2);o(N_cl,3);o(N_cl,4)];

        Nline1 = ceil(N_cl/2); Nline2 = N_cl - Nline1;
        x1 = rand(Nline1,1)*6-1; y1 = -1 + randn(Nline1,1)*noise;
        x2 = -1 + randn(Nline2,1)*noise; y2 = rand(Nline2,1)*4-1;
        labels = [labels;o(N_cl,5)];
        data = [data;x1,y1;x2,y2];
        x1 = rand(Nline1,1)*6-2; y1 = 4 + randn(Nline1,1)*noise;
        x2 = 4 + randn(Nline2,1)*noise; y2 = rand(Nline2,1)*4;
        data = [data;x1,y1;x2,y2];
        labels = [labels;o(N_cl,6)];

        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'random3'
        N_cl = ceil(N/4); % points in each cluster/subcluster
        mu = [0,0; 0,8; 8,0; 8,8];
        s1 = 0.8;
        data = mvnrnd(mu(1,:),[1,-0.8;-0.8,1],N_cl);
        data = [data; mvnrnd(mu(2,:),ones(1,size(mu,2))*s1,N_cl)];
        labels = [o(N_cl,1);o(N_cl,2)];
        [spd, spl] = generate_data_2d('spirals', N_cl);
        % Rescale
        mi = repmat(min(spd),N_cl,1);
        spd = 5*(spd - mi)./(repmat(max(spd),N_cl,1)-mi);
        data = [data;spd(:,1)+mu(4,1)-2.5 spd(:,2)+mu(4,2)-2.5];
        labels = [labels;spl+2];
        [spd, spl] = generate_data_2d('concentric_circles_3', N_cl);
        % Rescale
        mi = repmat(min(spd),N_cl,1);
        spd = 5*(spd - mi)./(repmat(max(spd),N_cl,1)-mi);
        data = [data;spd(:,1)+mu(3,1)-2.5 spd(:,2)+mu(3,2)-2.5];
        labels = [labels;spl+4];

    case 'randomised_normal'
        k = randi([2,20]); % number of clusters
        N_cl = ceil(N/k);
        high = 20; low = 0;
        data = []; labels = [];
        for i = 1:k
            A = randn(2);
            A = A'*A; % random covariance matrix
            data = [data; mvnrnd([rand*(high-low)+low, ...
                rand*(high-low)+low],A,N_cl)];
            labels = [labels; o(N_cl,i)];
        end
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'randomised_triangle'
        k = randi([2,20]); % number of clusters
        N_cl = ceil(N/k);
        r = 3; % offset from the peak of the triangle
        data = []; labels = [];
        for i = 1:k
            b = rand(1,2)*20;
            a1 = b(1) - rand*r; c1 = b(1) + rand*r;
            a2 = b(2) - rand*r; c2 = b(2) + rand*r;
            pd = makedist('Triangular','a',a1,'b',b(1),'c',c1);
            temp1 = random(pd,N_cl,1);
            pd = makedist('Triangular','a',a2,'b',b(2),'c',c2);
            temp2 = random(pd,N_cl,1);
            data = [data; temp1(:),temp2(:)];
            labels = [labels;ones(N_cl,1)*i];
        end
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'saturn'
        N_cl = ceil(N/2);
        s = 0.05; % noise
        % ellipse
        theta = rand(N_cl,1)*2*pi;
        a = 2.5; b = 0.6;
        data = [sin(theta)*a,cos(theta)*b];
        data = [data; sin(theta)*1.5,cos(theta)*1.5];
        data = data + randn(size(data))*s;
        labels = [o(N_cl,1);o(N_cl,2)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'sixteen_blocks' %------------------------------------------------
        k = 4; % block size
        step = round(2*k);
        data = []; labels = []; cluster_n = 1;
        [x,y] = meshgrid(1:k,1:k);
        for i = 1:4
            X = x(:)+i*step;
            for j = 1:4
                Y = y(:)+j*step;
                data = [data;X,Y];
                labels = [labels; o(k^2,cluster_n)];
                cluster_n = cluster_n + 1;
            end
        end

    case 'spirals' %-------------------------------------------------------
        noise = 0.02; 
        n_spirals = 3;
        revolutions = 1;
        data = []; labels = [];
        Nspi = ceil(N/n_spirals); % to trim later
        for i = 1:n_spirals
            theta = sort(0.3+rand(Nspi,1))*2*pi*revolutions + ...
                (i-1)*2*pi/n_spirals;
            r = (theta-(i-1)*2*pi/n_spirals)/(2*pi*revolutions);
            data =  [data;sin(theta).*r, cos(theta).*r];
            labels = [labels; o(Nspi,i)];
        end
        data = data + randn(size(data))*noise;
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'stormclouds'
        N_cl = ceil(N/2); % points in each cluster
        data = [rand(N_cl,1),rand(N_cl,1)*0.2+0.5;...
            rand(N_cl,1),rand(N_cl,1)*0.2];
        labels = [o(N_cl,1);o(N_cl,2)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 't_and_u'
        N_cl = ceil(N/2); % points in each cluster
        NT = ceil(N_cl/2);
        NU = ceil(N_cl/3);
        w = 0.18; % width of the bars
        ww = 0.6; % width of the horizontal bar
        data = [rand(NT,1)*w,rand(NT,1);...            
            rand(NT,1)*ww,rand(NT,1)*w+0.5-w/2;...
            rand(NU,1)*ww+(1-ww),rand(NU,1)*w;...
            rand(NU,1)*ww+(1-ww),rand(NU,1)*w+1-w;...
            rand(NU,1)*w+(1-w),rand(NU,1)];
        labels = [o(2*NT,1);o(3*NU,2)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);


    
    case 'ten_spherical'
        Param.mu = [-15,-3;-12,0;-6,3;2,-6;0,0;1,8;5,4;7,10;10,0;15,3];
        Param.sigma = {1,1,1,1,1,1,1,1,1,1};
         [data,labels] = gaussian_data(N,Param);
        
    case 'three_by_three'
        [x,y] = meshgrid(1:8:24,1:8:24);
        Param.mu = [x(:),y(:)];
        Param.sigma = {1,1,1,1,1,1,1,1,1};
         [data,labels] = gaussian_data(N,Param);
        

    case 'three_circles'
        [data,labels] = three_circles(N);

    case 'two_diamonds'
        N_cl = ceil(N/2);
        k = 2;
        cluster1 = rand(N_cl,2);
        cluster2 = rand(N_cl,2);
        R = [cos(pi/4), -sin(pi/4);sin(pi/4) cos(pi/4)];
        temp1 = (R*cluster1')';
        temp2 = (R*cluster2')';
        data = [temp1(:,1), temp1(:,2)*k;...
            temp2(:,1)+sqrt(2), temp2(:,2)*k];
        labels = [o(N_cl,1);o(N_cl,2)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'two_u'
        [data,labels] = two_u;

    case 'half_rings' %---------------------------------------------------
        noise = 0.2;
        N1 = round(0.25*N); N2 = N - N1;
        x = rand(N1,1)*pi - pi/2; % between A*pi and (B+A)*pi
        x1 = 0.65*sin(x) + 2*noise*rand(N1,1);
        y1 = 0.65*cos(x) + 2*noise*rand(N1,1);
        x = rand(N2,1)*pi - pi/2;
        x2 = sin(x) + noise*rand(N2,1);
        y2 = 0.4 - (cos(x) + noise*rand(N2,1)); % more noise
        data = [x1,y1;x2 + 1.1,y2]; % displace x1
        labels =  [o(N1,1); o(N2,2)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'wingnut'
        data = []; labels = [];
        gap = 0.03;
        s = 0.3;
        while size(data,1) < N
            if rand < 0.5
                % left
                x = randn*s+0.5; y = randn*s+1;
                if x>0 && x<(0.5-gap) && y>0 && y<1
                    data = [data; x,y];
                    labels = [labels;1];
                end
            else
                % right
                x = randn*s+0.5; y = randn*s;
                if x>0.5+gap && x<1 && y>0 && y<1
                    data = [data; x,y];
                    labels = [labels;2];
                end
            end
        end

    case 'worms'
        N_cl = ceil(N/4); % equal number of clusters ----------------------
        noise = 0.1;
        t = sort(-pi*0.3+rand(N_cl,1)*2*pi*0.3);
        r1 = 0.7; % radius
        worm1 = [sin(t)*r1+8,cos(t)*r1+8.5];
        data = worm1;
        labels = o(N_cl,1);

        t = sort(-pi*0.3+rand(N_cl,1)*2*pi*0.3);
        Theta = -1*pi; % rotation angle
        R = [cos(Theta) sin(Theta);-sin(Theta) cos(Theta)];
        r2 = 0.7; % radius
        worm2 = (R*[sin(t)*r2,cos(t)*r2]')';
        worm2(:,1) = worm2(:,1) + 4;
        worm2(:,2) = worm2(:,2) + 10;
        data = [data;worm2];
        labels = [labels;o(N_cl,2)];

        t = sort(-pi*0+rand(N_cl,1)*2*pi);
        Theta = -0.65*pi; % rotation angle
        R = [cos(Theta) sin(Theta);-sin(Theta) cos(Theta)];
        r3 = 1.2; % amplitude
        worm3 = (R*[t,sin(1.2*t)*r3]')';
        worm3(:,1) = worm3(:,1) + 7.5;
        worm3(:,2) = worm3(:,2) + 6;
        data = [data;worm3];
        labels = [labels;o(N_cl,3)];

        t = sort(rand(N_cl,1)*pi);
        Theta = 0*pi; % rotation angle
        R = [cos(Theta) sin(Theta);-sin(Theta) cos(Theta)];
        r4 = 1; % amplitude
        worm4 = (R*[t,abs(sin(t))*r4]')';
        worm4(:,1) = worm4(:,1) + 7.5;
        worm4(:,2) = worm4(:,2) + 7;
        data = [data;worm4];
        labels = [labels;o(N_cl,4)];
        data = data + randn(size(data))*noise;
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'xor'
        Param.mu = [0,0;0,10;10,0;10,10];
        Param.sigma = {1,1,1,1}; 
        [data,labels] = gaussian_data(N,Param);

    case 'xor_big_and_small'
        Param.mu = [0,0;0,10;10,0;10,10];
        Param.sigma = {1,0.2,0.2,1}; 
        [data,labels] = gaussian_data(N,Param);

    case 'xor_different_cardinalities'
        Param.mu = [0,0;0,10;10,0;10,10];
        Param.sigma = {1,1,1,1};
        N_cl = ceil(N/10);
        [data,labels] = gaussian_data([4*N_cl,N_cl,N_cl,4*N_cl],Param);
        

    case 'yin_yang'
        [data,labels] = yin_yang_data(N);

end

if nargin == 0 % continue the default example
    figure, hold on
    scatter(data(:,1),data(:,2),12,labels,"filled")
    axis equal
    grid on
end
