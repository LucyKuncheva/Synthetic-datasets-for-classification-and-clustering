function [data, labels] = circle_2_rectangles(N,Param)

% Sort out defaults
if nargin == 0
    N = [200,200,200]; % points
    Ntot = sum(N);
end

if nargin < 2
    Param.noise = 0.1;
    Param.radius = 1.5;
end

if numel(N) == 1
    % One size = equal cluster sizes
    [N1,N2,N3] = deal(ceil(N/3));
    Ntot = N;
else
    % Assuming there are exactly three numbers!
    N1 = N(1); N2 = N(2); N3 = N(3);
    Ntot = sum(N);
end

noise = Param.noise;
ra = Param.radius;

theta = rand(N1,1)*2*pi;
data = [sin(theta)*ra, cos(theta)*ra];
data = data + randn(size(data))*noise; 
data = [data;rand(N2,1)*2+4,rand(N2,1)*3.5-2;...
    rand(N3,1)*9-2,rand(N3,1)*1-5;];

labels = [ones(N1,1);ones(N2,1)*2;ones(N3,1)*3];
data = data(1:Ntot,:);
labels = labels(1:Ntot);

% % Visual Check
% close all
% figure, hold on
% scatter(data(:,1),data(:,2),12,labels)
% axis equal
% title(size(data,1))
