function [data, labels] = yin_yang_data(~)

% % Sort out defaults
% if nargin == 0
%     N = 500; % points
% end

N = 500; % to make it a "fixed dataset" as it is on a grid

grid_size = ceil((8+2*sqrt(N*pi))/pi);
gap = grid_size/30;

k = grid_size; mk = k/2;
[x,y] = meshgrid(1:k,1:k); x = x(:); y = y(:);
data = [x,y];
labels = ones(k^2,1);

% Main circle
labels((x-mk).^2+(y-mk).^2 > (k/2)^2+1) = 0;

% Sine-like boundary
zx = linspace(-pi,2*pi,k);
zy = sin(zx) * k/5 + k/2;
la = y < sin(x/k*2*pi) * k/5 + k/2; % Eh, Baba Lisica!
labels(labels == 1 & la) = 1;
labels(labels == 1 & ~la) = 2;
boundary = [zx(:)/(2*pi)*(k-1)+1,zy(:)];
mindi = min(pdist2(data,boundary),[],2);
labels(mindi < gap) = 0;

% % Small circles
index1 = ((x-k/4).^2+(y-k/2).^2 < (k/8)^2);
index2 = ((x-3*k/4).^2+(y-k/2).^2 < (k/8)^2);
labels(index1) = 3; labels(index2) = 4;
% % Clusters 3 and 4 can subsequently be relabelled as classes 1 and 2

% Small gaps 
labels(index1 & (x-k/4).^2+(y-k/2).^2 > (k/8-2*gap)^2) = 0;
labels(index2 & (x-3*k/4).^2+(y-k/2).^2 > (k/8-2*gap)^2) = 0;

data(labels == 0,:) = [];
labels(labels == 0) = [];

% Visual Check
% close all
% figure, hold on
% scatter(data(:,1),data(:,2),12,labels)
% axis equal
% title(size(data,1))
