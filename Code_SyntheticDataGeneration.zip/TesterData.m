clear, clc, close all

% A tester for generating artificial datasets

L = 500;

% Create the folder structure ---------------------------------------------
if ~exist('GeneratedData','dir')
    mkdir('GeneratedData')
end

if ~exist('GeneratedData/TwoDFixedPoints','dir')
    mkdir('GeneratedData/TwoDFixedPoints')    
end

fd1 = ['GeneratedData/TwoDAnyPoints_', num2str(L),'/'];
if ~exist(fd1,"dir")
    mkdir(fd1)
end

fd2 = ['GeneratedData/ThreeD_',num2str(L),'/'];
if ~exist(fd2,"dir")
    mkdir(fd2)
end

%--------------------------------------------------------------------------

for dims = [2,3]

    if dims == 2

        Data = {'aligned_bananas','aggregation','arcs',...
            'balls_and_baguettes',...
            'bars','boat','cigar','circle_and_3_gaussians', ...
            'circle_2_rectangles',...
            'concentric_circles_3','enclosure',...
            'flower','filled_circle',...
            'filled_circle_2',...
            'four_corners_clear',...
            'four_corners_noise','four_lines',...
            'gestalt','happy_wave','half_rings',...
            'gaussians_3_touching',...
            'gaussians_5_compact',...
            'gaussians_5_unequal',...
            'gaussians_1_big_2_small', 'orange','petals','random1', ...
            'random2','random3', 'randomised_normal', ...
            'randomised_triangle',...
            'saturn',...
            'sixteen_blocks',...
            'spirals','stormclouds','t_and_u',...
            'ten_spherical',...
            'three_by_three',...
            'three_circles', 'two_diamonds','two_u',...
            'wingnut','worms',...
            'xor','xor_big_and_small',...
            'xor_different_cardinalities','yin_yang'};

        Fixed = [1,2,2,1,1,1,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,1,...
            1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,2,1,1,...
            1,1,1,2];

        [Data, idx] = sort(Data);
        Fixed = Fixed(idx);
        DataNum = numel(Data);


        sizes = zeros(DataNum,1);
        clusters = zeros(DataNum,1);

        figure('units','normalized','outerposition',[0 0 1 1]);
        
        k = ceil(sqrt(numel(Data)));
        for i = 1:numel(Data)
            Data{i}
            [a,l] = generate_data_2d(Data{i},L);
            sizes(i) = size(a,1);
            clusters(i) = max(l);

            subplot(k,k,i)
            scatter(a(:,1),a(:,2),4,l,'filled')
            axis equal
            grid on
            title(Data{i},'Interpreter','none')

            if Fixed(i) == 1
                fd = ['GeneratedData/TwoDAnyPoints_',...
                    num2str(L),'/'];
                writematrix([a,l],[fd,'Data_',...
                    Data{i},'_',num2str(L),'.csv'])
            else
                fd = 'GeneratedData/TwoDFixedPoints/';
                writematrix([a,l],[fd,'Data_',Data{i},'_',...
                    num2str(size(a,1)),'.csv'])
            end
        end

        DataAll = Data;
        SizesAll = sizes;
        ClustersAll = clusters;

    elseif dims == 3

        Data = {'atom','chainlink','hepta','tetra','torus_and_rod'};

        sizes = zeros(numel(Data),1);
        clusters = zeros(numel(Data),1);
        fd = ['GeneratedData/ThreeD_',num2str(L),'/'];

        figure
        k = ceil(sqrt(numel(Data)));
        for i = 1:numel(Data)
            Data{i}
            [a,l] = generate_data_3d(Data{i},L);
            sizes(i) = size(a,1);
            clusters(i) = max(l);

            subplot(k,k,i)
            scatter3(a(:,1),a(:,2),a(:,3),3,l,'filled')
            axis equal
            grid on
            title(Data{i},'Interpreter','none')
            rotate3d

            writematrix([a,l],[fd,'Data_',Data{i},'_',num2str(L),'.csv'])


        end
        DataAll = [DataAll, Data];
        SizesAll = [SizesAll;sizes];
        ClustersAll = [ClustersAll;clusters];
        FixedAll = [Fixed(:); ones(numel(Data),1)];


    end
end

% Save a summary file -----------------------------------------------------

DataNames = DataAll(:);
T = table(DataNames,SizesAll,ClustersAll,FixedAll);
writetable(T,'DataSetsDetails.csv')

%--------------------------------------------------------------------------

