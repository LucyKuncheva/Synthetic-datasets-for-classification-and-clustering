function [data, labels] = two_u
k = 15;
p = 8;
d = 5;
leg = [ones(k,1), (p+1:p+k)';ones(k+1,1)*2, (p+1:p+k+1)';...
    ones(k+2,1)*3, (p+1:p+k+2)';ones(d,1)*4,(p+k+4-d:p+k+3)';...
    ones(d-1,1)*5,(p+k+5-d:p+k+3)';ones(d-1,1)*6,(p+k+5-d:p+k+3)';...
    ones(d-1,1)*7,(p+k+5-d:p+k+3)'];

leg_flippedlr = leg;
leg_flippedlr(:,1) = 2*max(leg_flippedlr(:,1))+1 - leg_flippedlr(:,1);   
data = [leg; leg_flippedlr];
u_flipped = data;
u_flipped(:,2) = max(u_flipped(:,2))+1 - u_flipped(:,2);
u_flipped(:,1) = u_flipped(:,1) + max(u_flipped(:,1))/2-1;
labels = [ones(size(data,1),1);ones(size(data,1),1)*2];
data = [data;u_flipped];

% % Visual Check 
% close all
% figure, hold on
% scatter(data(:,1),data(:,2),12,labels)
% axis equal off
% title(size(data,1))
