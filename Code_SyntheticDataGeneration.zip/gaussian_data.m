function [data,labels] = gaussian_data(N,Param)
if nargin == 0
    N = 1000;
end
if nargin < 2
    Param.mu = [0,0;4,4];
    Param.sigma = {1, 3};
end

mu = Param.mu; 
[k,n] = size(mu); % number of clusters and features
sigma = Param.sigma;

if numel(N) == 1
    Ntot = N;
    N_cl = ceil(N/k);
    N = ones(1,k) * N_cl; % cluster sizes
else % otherwise the cluster numbers are already provided
    Ntot = sum(N);
end 
data = []; labels = [];
for i = 1:k
    if numel(sigma{i}) == 1
        sigma{i} = eye(n)*sigma{i};
    end
    data = [data; mvnrnd(mu(i,:),sigma{i},N(i))];
    labels = [labels;ones(N(i),1)*i];
end

data = data(1:Ntot,:);
labels = labels(1:Ntot);

% % Visual Check
% close all
% figure, hold on
% scatter(data(:,1),data(:,2),12,labels)
% axis equal
% title(size(data,1))