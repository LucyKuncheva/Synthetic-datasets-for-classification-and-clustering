function [data, labels] = generate_data_3d(name, N)
%=======================================================================
%GENERATE_DATA_3D Generates a chosen dataset
%    [data, labels] = generate_data_3d(name, N)
%    Returns data and labels for a chosen dataset. The collection of
%    datasets has been created to replicate popular toy datasets in the
%    literature on clustering and classification.
%
%   Input -----
%      'name': the chosen dataset (string, default = 'chainlink')
%      'N': number of points (default = 300) Where there is uniform
%           background noise in the data, 10% of the points are allocated
%           to the noise.
%
%   Output -----
%      'data':
%      'labels':
%
%   Datasets available to generate:
%
%    atom = outer sphere (noisy) and gaussian nucleus [1] 
%
%    chainlink = two linked doughnuts [1]
% 
%    hepta = 6 clusters on a circle in 3d, equally spaced, and 
%             one more compact in the middle [1]
%
%    tetra = four gaussian 3d clusters [1]
%
%   torus_and_rod = rod is through the centre of the noisy torus
%
%
% [1] JoseGarcia21


%========================================================================

% (c) Lucy Kuncheva                                                 ^--^
% 02.05.2023 -----------------------------------------------------  \oo/
% -------------------------------------------------------------------\/-%

if nargin < 2
    N = 200;
end
if nargin == 0 % default example
    name = 'chainlink';
end

o = @(a,b) ones(a,1)*b; % label generator

switch name

    case 'atom'
        s1 = 0.1; % std of the centre
        s2 = 0.05; % std of the noise on the outer sphere

        T = ceil(N/2);
        centre = [0,0,0]; radius = 4;
        x = sampling_from_hypersphere(centre,radius,T,s2);
        y = mvnrnd(centre,eye(3)*s1,T);
        data = [x;y]; labels = [o(T,1);o(T,2)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'chainlink'
        s = 0.1;
        T = ceil(N/2);
        x = sampling_from_torus([0,0],1,T,s);
        yy = sampling_from_torus([0,0],1,T,s);

        % rotate about y-axis
        theta = pi/2;
        R = [cos(theta), 0, sin(theta);0 1 0;-sin(theta), 0, -cos(theta)];
        y = yy*R';
        y(:,2) = y(:,2) - 1;
        data = [x;y]; labels = [o(T,1);o(T,2)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);

    case 'hepta'  
        k = 7;
        T = ceil(N/k);
        s1 = 0.1;
        s2 = 0.6; % std of the clusters
        centre = [0,0,0]; radius = 4;
        pos = linspace(0,2*pi,k);
        data = []; labels = [];
        for i = 1:k-1
            data = [data; mvnrnd(centre+[radius*sin(pos(i)), ...
                radius*cos(pos(i)),0],eye(3)*s2,T)];
            labels = [labels;o(T,i)];
        end
        data = [data; mvnrnd(centre,eye(3)*s1,T)];
        labels = [labels;o(T,k)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);

        

    case 'tetra' % clusters on a circle in 3d, equally spaced
        k = 4;
        T = ceil(N/k);
        s = 0.8; % std of the clusters
        centre = [0,0,0]; radius = 4;
        pos = linspace(0,2*pi,k+1);
        data = []; labels = [];
        for i = 1:k
            data = [data; mvnrnd(centre+[radius*sin(pos(i)), ...
                radius*cos(pos(i)),0],eye(3)*s,T)];
            labels = [labels;o(T,i)];
        end
        data = data(1:N,:); % trim off
        labels = labels(1:N);


    case 'torus_and_rod'
        s = 0.1;
        T = ceil(N/2);
        x = sampling_from_torus([0,0],1,T,s);
        tz = rand(T,1)*2 - 1; txy = randn(T,2)*s;
        y = [txy tz];
        data = [x;y]; labels = [o(T,1);o(T,2)];
        data = data(1:N,:); % trim off
        labels = labels(1:N);

end

if nargin == 0 % continue the default example
    figure, hold on
    scatter3(data(:,1),data(:,2),data(:,3),12,labels,"filled")
    axis equal
    grid on
end
