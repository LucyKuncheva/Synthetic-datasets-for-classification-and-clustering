function [data, labels] = enclosure
k = 35;
b = 30;
a = zeros(k,b);
labels = zeros(k,b);

t = 3;
for i = 1:t
    a(i:end-i+1,t+1-i) = 1;
    a(i:end-i+1,end-t-1+i) = 1;
end
a(:,t:end-t-1) = 1;
a(2*t:end-2*t+1,2*t:end-2*t) = 0;
labels(a == 1) = 1;

% Rectangle
left_point = floor(0.3*b); right_point = ceil(0.7*b);
top_point = floor(0.3*k); bottom_point = ceil(0.4*k);
a(top_point:bottom_point,left_point:right_point) = 1;
labels(top_point:bottom_point,left_point:right_point) = 2;

% Dimond
top_point = floor(0.6*k);
step_back = round(linspace(b/2,left_point,t));
step_forward = round(linspace(b/2,right_point,t));
for i = 1:t
    a(top_point+i-1,step_back(i):step_forward(i)) = 1;
    a(top_point+t+1-(i-1),step_back(i):step_forward(i)) = 1;
    labels(top_point+i-1,step_back(i):step_forward(i)) = 3;
    labels(top_point+t+1-(i-1),step_back(i):step_forward(i)) = 3;
end

[x,y] = find(a);
data = [y(:),k-x(:)+1];
labels = labels(:);
labels(labels == 0) = [];

% % Visual Check 1
% close all
% spy(a)
% axis off

% % Visual Check 2
% close all
% figure, hold on
% scatter(data(:,1),data(:,2),12,labels)
% axis equal
% title(size(data,1))
