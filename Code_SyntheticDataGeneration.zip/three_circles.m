function [data, labels] = three_circles(N,Param)

% Sort out defaults
if nargin == 0
    N = [200,200,200]; % points
    Ntot = sum(N);
end

if nargin < 2
    Param.noise = 0.1;
    Param.centres = [0,0;-1,-2;1,-2];
    Param.radii = [2,2,2];
end

if numel(N) == 1
    % One size = equal cluster sizes
    [N1,N2,N3] = deal(ceil(N/3));
    Ntot = N;
else
    % Assuming there are exactly three numbers!
    N1 = N(1); N2 = N(2); N3 = N(3);
    Ntot = sum(N);
end

noise = Param.noise;
mu = Param.centres;
ra = Param.radii;

theta = rand(N1,1)*2*pi;
data = [sin(theta)*ra(1) + mu(1,1), cos(theta)*ra(1) + mu(1,2)];
theta = rand(N2,1)*2*pi;
data = [data; sin(theta)*ra(2) + mu(2,1), cos(theta)*ra(2) + mu(2,2)];
theta = rand(N3,1)*2*pi;
data = [data; sin(theta)*ra(1) + mu(3,1), cos(theta)*ra(3) + mu(3,2)];
data = data + randn(size(data))*noise;

labels = [ones(N1,1);ones(N2,1)*2;ones(N3,1)*3];
data = data(1:Ntot,:);
labels = labels(1:Ntot);

% % Visual Check
% close all
% figure, hold on
% scatter(data(:,1),data(:,2),12,labels)
% axis equal
% title(size(data,1))
